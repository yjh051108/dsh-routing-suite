# dsh-graded-mode（分级模式 v3.2）

会话级两级任务协议插件：**一次性触发流程（/graded <任务>），未触发 = 官方原样**（零工具注册、零注入）。

## v3.2（2026-09-02）——体验增强版（脑暴出题 / 时序即时 / 小类模式粒度）

- **脑暴出题制**：ask_user_question 选择题对齐（≤5 题/轮、多轮、歧义全结清）+**必选模式题**（correct/experience/research）——模式=用户点选，非模型自报（修复"视觉项目被判 correct→体验验收句缺失"）。
- **指引即时**：大小类引导走 next-step（锁后同 turn 即达，无过期）；锁定回执即呈完整规格单（北极星+需求+树）；审核=唯一确认请求；『修改』回滚自动开口（reject-ack）。
- **小类粒度模式**：item.mode（缺省继承会话）——全栈按小类切验收重心；聚焦注入明示模式；树/面板标注。
- **北极星锚定**：开工前一眼=目的+验收锚（替代声明式"开工前自问"）。
- **委派改写制**：允许情景化改写委托信，规格事实逐条完整、验收锚=盘档规格。
- 模式只认用户改口（scanMode 限 user，防模型漂移）。

```
命令/文本/自主 commit_star → 脑暴出题（含模式必选）→ commit_star 定稿
→ L1 规格化（组 spec/accept/verify）→ 锁定（同轮 phaseL2）
→ L2 规格化（小类 spec/accept/do/verify/item.mode）→ 锁定（回执=规格单）
→ 审核（唯一请求）→ 确认/修改 → 执行（三段式+星锚+按小类模式铁律）→ 打卡 → 组收官逐条核对 → 终验+审计
```

历史（v3.1/v4/v3）见下。

---

# 分级模式 v3.1（历史基线）

## v3.1（2026-09-02）——规格化重设计（spec 链 + 脑暴 + 执行形态 + 超级面板）

```
【自主进入】模型无需 /graded：直接调 commit_star(目的宣言) 即激活（off → 脑暴一次对齐 → l1-edit）——
   /graded <任务>（用户触发）→ 【头脑风暴·需求对齐】（信息齐平+疑点清单+边界+北极星草案+模式自报）
→ commit_star 定稿（北极星=目的宣言+需求+非目标+假设）
→ L1 编辑：大类标题+组 spec+组 accept(≤3)+组 verify → 锁定
→ L2 编辑：小类 = 标题+概念+spec+accept(文法化)+do+verify → 锁定（全量校验,缺即拒）
→ 审核 = 完整规格评审单（北极星+树+双层规格+形态矩阵）→ 用户『确认』/『修改』
→ 执行：每小类注入 = 规格前置三段式（任务 spec→验收 accept→执行形态→铁律→打卡）
   注入差异=结构差异（自执行/委派 skill 卡/编排 skill 卡/红队裁决/双轨规范）
→ 组收官：证据回放→组级标准逐条核对（严苛>小类）→组 verify（红队先裁后定）→标定
→ 终验：finalCheck 六项+北极星达成核对
```

| 工具（6） | 作用 |
|---|---|
| `commit_star` | 脑暴定稿（purpose 必填/不照抄原文/审核前可修订/开发期只读） |
| `edit_plan` | L1 组规格（spec/accept/verify 必填）；L2 小类规格（spec/accept/do/verify 必填） |
| `lock_stage` | 锁定（L1 复检组规格 / L2 全量复检——先复检后写入,拒绝=状态不变） |
| `mark_task` | 打卡（redteam 门：verify=redteam 未裁决通过不得打卡） |
| `redteam_verdict` | 红队裁决（pass/reject+问题清单；打回→修复→再裁决=再审批义务） |
| `revise_do` | 形态修订（do 可改+登记轨迹；verify 只读——验收承诺不打折） |

- **模式**：correct/experience/research 三措辞包（开局自报 [模式:x] 或随时改口；accept 文法随模式：可测量断言/感受断言+可复现动作/可复核断言）。
- **状态单轨=磁盘**：热重载零中断；注入幂等（先注后键,无双注）；审计端点 `/graded-mode/api/audit`（注入计数/指纹/红队/唯一率）。
- **超级面板**：徽章=阶段+模式+当前唯一任务+红队灯；点击全屏三层树（组卡→小类行→项层规格+红队历史）+量化条（打卡/标准覆盖/单注率）+★北极星栏+黄旗⚠。
- 测试 **53/53**；E2E 自验脚本 `scripts/e2e-3.1.mjs`（全链 dogfood）+ `scripts/e2e-redteam-group.mjs`（组级红队实战链，隔离目录零污染）。

历史（v4/v3 记录）见下。

---

# 分级模式 v4（历史基线）

会话级两级任务协议插件：**一次性触发流程（/graded <任务>），未触发 = 官方原样**（零工具注册、零注入）。
v4 流程（用户拍板）：注入「先想大类」→ `edit_plan(L1)` 大类编辑 → `lock_stage(L1)` 锁定 →
自动注入「三概念分化」→ `edit_plan(L2)` 小类编辑 → `lock_stage(L2)` 锁定 → **所有门关闭,插件自动弹出树状图审核**（原生 `ctx.userQuestions.ask`,不经过模型转述）→ 通过则逐小类执行,拒绝则全解锁回大类编辑。

## v4 变更（2026-09-01）——「编辑+锁定两工具,工具驱动,零字符串解析」

- **工具精简为两个**（level 参数切语义,不做阶段隔离的 restrict——"锁"是工具自身状态）：

| 工具 | 作用 |
|---|---|
| `edit_plan` | level=L1 写大类列表；level=L2 写完整树（groups[].items ≤3 概念）。**编辑即展示**（立即落盘） |
| `lock_stage` | 锁定当前层：L1 锁 → 切小类编辑；L2 锁 → 所有门关 → 自动树状审核 |

- **锁了就是锁了**：已锁层 `edit_plan` 报错；解锁唯一入口 = 用户审核拒绝（全解锁回大类编辑,按意见改）。
- **顺序强制**：大类 → 锁定 → 小类 → 锁定 → 审核（阶段推进 = 工具调用事件,不做任何内容识别/解析）。
- **数据面 todo max**：清单 = 结构化树（`graded/plan` / `graded/lock` 事件快照）,**不写官方 todo_write**——官方任务面板零污染。
- **官方面板树状图**：client 插件（keyed toolview 覆盖 edit_plan/lock_stage 通用行）把结构化参数渲染为可展开收起的树（🔒 锁徽标 / 概念 chips）;审核 detail 树同源。
- 复刻 v3 的坑（schema 标准形态 / lib 构建 / DSH_HOME）见本文件下方「开发闭环」与仓库 docs/design-v4-edit-lock.md。


会话级两级任务协议插件：**一次性触发流程（/graded <任务>），未触发 = 官方原样**（零工具注册、零 restrict、零注入）。
流程：命令带任务触发 → 注入思考大分类 → plan-l1 锚定 #L1 → 注入三概念分化 → plan-l2 编辑 #L2 → 再锚定 → 自动弹审核确认（树状图 + 确认/取消/输入框）→ 确认后逐小类执行（mark-l2 逐个标定；大类全完 mark-l1；收尾 delivery_check）。

## v3 变更（2026-09-01）

- **修复双注入**：命令通道触发时同步标记 injected，pre-step 为去重后的单一注入点——触发一次只注入一条【分级·第一步】。
- **阶段工具面**（用户定调"大 todo 规划/小 todo 规划/小 todo 标定/大 todo 标定"）：

| 工具 | 阶段 | 作用 |
|---|---|---|
| `plan-l1` 大类规划 | planning | 整份替换为 #L1 大类清单（items[].title 裸标题即可） |
| `plan-l2` 小类规划 | splitting | 整份替换为 #L1+#L2 合并清单（≤3 概念；超限**提示不拒绝**） |
| `mark-l2` 小类标定 | develop | 逐个标记小类行 pending/in_progress/completed（精确标题匹配） |
| `mark-l1` 大类标定 | develop | 标记大类行 |

- **阶段硬隔离**（restrict 只过滤继承面；本插件工具注册在 agent 层不受影响）：
  - planning/splitting：全局工具全面具化（只剩各自规划工具）
  - awaiting：只剩 `ask_user_question`
  - develop/final：恢复官方全量任务工具
  - 切换靠 **disposer 精确解锁后重设**（绝不二次 restrict 交集——见坑 1）
- **状态机**：develop 全部小类完成 → **final**（此前只注入收尾不置态）。
- **重复触发**：同会话再次 /graded 重置注入标记/确认状态（新起一条完整流程）。

## 流程（状态机）

```
/graded <任务>（一次性触发,off/status 兼容）
→ planning：注入【第一步】→ plan-l1 写大类 → todo/write 事件 → splitting
→ splitting：注入【第二步】→ plan-l2 写小类 → 再锚定 → awaiting
→ awaiting：注入【第三步】→ 引导 ask_user_question（graded-plan-review 树状确认）
→ develop（确认通过）：逐小类注入【当前小类】→ 小类完成 mark-l2 → 大类全完 mark-l1 +【大类检查】
→ final：全部完成 → 【收尾检查】+ delivery_check
```

## 命令

> 注：DSH 命令名只接受 ASCII kebab-case（`/^[a-z][a-z0-9_-]*$/u`），
> "分级" 中文名不合法，故命令用 `graded`（提示语内文仍是中文）。

- `/graded <任务>`  一次性触发（主要用法：斜杠命令带要求=触发，不带任务不启动流程）
- `/graded status`  查看当前阶段
- `/graded off`     关闭：工具面清空，恢复官方行为

## 协议（todo content 编码,官方 todo 同源）

```
#L1 店壳
#L2 店壳 | 玻璃橱窗 | 概念: 玻璃,窗框,雨痕
```

- L1 = 一级大类（训练习惯的自然分类：店壳/店内/街道/道具/动效）
- L2 = 二级小类（≤3 个核心概念、能一图/一跑验证；超限提示不拒绝）
- 读写走官方 `todo/write` 事件流（whole-list replacement），GUI 直接可见；官方 dsh-tool-todo 源码零改动

## 结构

```
src/index.js        插件 apply：commands + session/event + agent/pre-step（工具面同步+注入）
src/tools.js        四个工具定义（agent 层注册）+ 阶段工具注册表
src/todo-store.js   官方 todo 快照纯函数层（读/生成/匹配/更新,可单测）
src/mode-state.js   会话级状态机（off/planning/splitting/awaiting/develop/final）+ 阶段 restrict 面
src/plan-tree.js    #L1/#L2 content 前缀解析器（树/等级/焦点/大类完成）
src/inject-text.js  全部注入文本（协议/设计提醒/专注/大类检查/收尾,含阶段进度行）
```

## 装配（DSH 官方路径）

```bash
export PATH="/c/Users/Eldwen/AppData/Roaming/npm:/c/Users/Eldwen/AppData/Local/nvm/v22.20.0:$PATH"
DSH_HOME='C:/Users/Eldwen/.dsh' node /c/Users/Eldwen/AppData/Roaming/npm/node_modules/@deepseek-ai/dsh/lib/bin.js plugin --profile web add D:/dsh/dsh-graded-mode
# 重启 DSH web
```

## 验证

- 单元测试：`npm test`（plan-tree 7 + mode-state 12 + confirm 6 + tools 13 = **38 项**）全绿
- DSH 装配：`dsh plugin --profile web add D:/dsh/dsh-graded-mode`；重启后 `--dump-config` 含 `dsh-graded-mode`
- 实测链路（2026-08-31 v2）：/graded 触发 → 大类 → 分化 → 树状确认（G5 会话）；v3 待实战观测（工具面/单通道注入）

## 开发闭环（改代码 → 热重载）

```bash
node scripts/build.mjs        # src → lib/（纯复制,零编译）
# 会话内：dev_reload_package dsh-graded-mode  → 新代码在线生效（fiber 重建,失败回滚旧代）
```

> 装配形态 = **lib 构建产物**（package.json exports 指向 lib/index.js）+ 注入器 registry 管理
> （dev_inject 双路径：bundles/junction 官方链 + 运行时 loader.create）。改源码必须先 build，
> 不 build 则热重载跑旧代码（重载器的磁盘降级路径只在 lib/ 存在时可达）。

## 红线

- 不碰官方 dsh-tool-todo 源码（content 协议零侵入）
- 不新增"确认"工具（ask_user_question + intent:'plan-review' 原生确认）
- 不常驻监督：阶段切换注入一次；未激活 = 零注入零改变（工具都不注册）
- restrict 只用 disposer 精准切换，绝不二次 restrict（交集空集会全灭工具）

